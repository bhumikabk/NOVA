export interface AIModel {
  id: string
  name: string
  provider: string
  description: string
  icon: string
  available: boolean
}

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system'
  content: string
}

export interface EmotionContext {
  emotion: string
  mood: string
  confidence: number
}

export class AIModelService {
  private currentModel: string = 'gemini'
  private models: AIModel[] = [
    {
      id: 'gemini',
      name: 'Google Gemini',
      provider: 'Google',
      description: 'Advanced conversational AI with multimodal capabilities',
      icon: '🤖',
      available: true
    },
    {
      id: 'gpt-4-mini',
      name: 'GPT-4 Mini',
      provider: 'OpenAI',
      description: 'Fast and efficient language model',
      icon: '🧠',
      available: false
    },
    {
      id: 'huggingface',
      name: 'Hugging Face',
      provider: 'Hugging Face',
      description: 'Open-source AI models',
      icon: '🤗',
      available: true
    }
  ]

  getModels(): AIModel[] {
    return this.models
  }

  getCurrentModel(): string {
    return this.currentModel
  }

  setCurrentModel(modelId: string): void {
    this.currentModel = modelId
  }

  getCurrentModelInfo(): AIModel | undefined {
    return this.models.find(model => model.id === this.currentModel)
  }

  async generateResponse(
    message: string, 
    userMood?: { primary: string; confidence: number },
    conversationHistory: ChatMessage[] = []
  ): Promise<string> {
    const modelInfo = this.getCurrentModelInfo()
    
    try {
      switch (this.currentModel) {
        case 'gemini':
          return await this.callGeminiAPI(message, userMood, conversationHistory)
        case 'gpt-4-mini':
          return await this.callOpenAIAPI(message, userMood, conversationHistory)
        case 'huggingface':
          return await this.callHuggingFaceAPI(message, userMood, conversationHistory)
        default:
          return this.getFallbackResponse(message, userMood)
      }
    } catch (error) {
      console.error(`Error with ${modelInfo?.name}:`, error)
      return this.getFallbackResponse(message, userMood)
    }
  }

  private async callGeminiAPI(
    message: string, 
    userMood?: { primary: string; confidence: number },
    conversationHistory: ChatMessage[] = []
  ): Promise<string> {
    const apiKey = import.meta.env.VITE_GEMINI_API_KEY || ''
    
    if (!apiKey || apiKey === '') {
      throw new Error('Gemini API key not configured')
    }

    // Check for crisis language first
    if (detectCrisisLanguage(message)) {
      return this.handleCrisisResponse(message)
    }

    const moodContext = userMood?.primary || 'neutral'
    const systemPrompt = getBookCounselorPrompt(moodContext, userName)
    
    // Build conversation context
    let conversationContext = ''
    if (conversationHistory.length > 0) {
      conversationContext += '\n' + conversationHistory.slice(-4).map(msg => 
        `${msg.role === 'user' ? 'User' : 'Nova'}: ${msg.content}`
      ).join('\n')
    }
    
    
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              { text: fullPrompt }
            ]
          }
        ],
        generationConfig: {
          temperature: 0.9,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 200,
        }
      })
    })

    if (!response.ok) {
      throw new Error(`Gemini API error: ${response.status}`)
    }

    const data = await response.json()
    const responseText = data.candidates?.[0]?.content?.parts?.[0]?.text || 'I apologize, but I could not generate a response.'
    
    // Clean up the response to remove any "Nova:" prefix
    return responseText.replace(/^Nova:\s*/i, '').trim()
  }

  private async callOpenAIAPI(
    message: string, 
    userMood?: { primary: string; confidence: number },
    conversationHistory: ChatMessage[] = []
  ): Promise<string> {
    const apiKey = import.meta.env.VITE_OPENAI_API_KEY || ''
    
    if (!apiKey || apiKey === '') {
      throw new Error('OpenAI API key not configured')
    }

    const moodContext = userMood || { primary: 'neutral', confidence: 0.5 }
    const systemPrompt = novaPersonality.generateSystemPrompt(moodContext)
    
    const messages = [
      { role: 'system', content: systemPrompt },
      ...conversationHistory.slice(-4),
      { role: 'user', content: message }
    ]

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages,
        max_tokens: 200,
        temperature: 0.8,
        presence_penalty: 0.1,
        frequency_penalty: 0.1
      })
    })

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status}`)
    }

    const data = await response.json()
    return data.choices[0]?.message?.content || 'I apologize, but I could not generate a response.'
  }

  private async callHuggingFaceAPI(
    message: string, 
    userMood?: { primary: string; confidence: number },
    conversationHistory: ChatMessage[] = []
  ): Promise<string> {
    const apiKey = import.meta.env.VITE_HUGGINGFACE_API_KEY || ''
    
    if (!apiKey || apiKey === '') {
      throw new Error('Hugging Face API key not configured')
    }

    const moodContext = userMood || { primary: 'neutral', confidence: 0.5 }
    const systemPrompt = novaPersonality.generateSystemPrompt(moodContext)
    const fullPrompt = `${systemPrompt}\n\nUser: ${message}\nNova:`

    // Use a better conversational model for mental wellness
    const response = await fetch('https://api-inference.huggingface.co/models/microsoft/DialoGPT-medium', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
          model: 'gpt-4o-mini',
        parameters: {
          max_length: 200,
          temperature: 0.9,
          do_sample: true,
          top_p: 0.9
        }
      })
    })

    if (!response.ok) {
      throw new Error(`Hugging Face API error: ${response.status}`)
    }

    const data = await response.json()
    return data[0]?.generated_text?.split('Nova:')[1]?.trim() || novaPersonality.generateResponse(message, moodContext).text
  }

  private handleCrisisResponse(message: string): string {
    return `I'm really sorry you're feeling this way. I'm not able to manage emergencies alone. If you are in immediate danger, please call your local emergency number now or go to the nearest emergency room. 

If you can, tell me whether you are safe right now and whether someone you trust is nearby. 

Would you like me to try to connect you to a human counselor or provide other emergency contact steps? I'm here to stay with you in this chat until you tell me you're safe.

Remember: You matter, and there are people who want to help you through this difficult time.`
  }

  private getFallbackResponse(message: string, userMood?: { primary: string; confidence: number }): string {
    const mood = userMood?.primary || 'neutral'
    
    const fallbackResponses = {
      sad: "I hear that you're going through a tough time. Your feelings are completely valid. Sometimes it helps to take things one moment at a time. Would you like to try a quick breathing exercise together?",
      anxious: "I can sense you're feeling overwhelmed right now. That's completely understandable. Let's focus on something small - can you tell me about one tiny thing that went okay today?",
      angry: "I can hear the frustration in your voice, and that's completely okay. Let's take a moment to breathe together. What's been building up this tension for you today?",
      happy: "I love seeing you in such a positive mood! Your happiness is wonderful. What's the best part about your day so far?",
      excited: "Your excitement is contagious! I'm so glad you're feeling this way. Tell me more about what's got you feeling so fantastic!",
      default: "Hi there! I'm Nova, your mental wellness companion. I'm here to support you through whatever you're going through. What's on your mind today?"
    }

    return fallbackResponses[mood as keyof typeof fallbackResponses] || fallbackResponses.default
  }

  getModelIntroduction(modelId: string): string {
    const introductions = {
      'gemini': "Hi! I'm Google Gemini 🤖 - I'm analytical and love helping with complex problems. I can understand context really well and provide detailed insights!",
      'gpt-4-mini': "Hello! I'm GPT-4 Mini 🧠 - I'm fast, efficient, and creative. I excel at understanding nuance and generating helpful responses quickly!",
      'huggingface': "Hey there! I'm from Hugging Face 🤗 - I represent the open-source AI community. I'm collaborative and love learning from our conversations!"
    }

    return introductions[modelId as keyof typeof introductions] || "Hi! I'm your new AI assistant, ready to help you!"
  }
}

import { getBookCounselorPrompt, detectCrisisLanguage } from './bookCounselorPrompt'
export const aiModelService = new AIModelService()