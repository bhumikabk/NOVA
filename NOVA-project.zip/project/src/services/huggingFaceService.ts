// Hugging Face Inference API Service
const HUGGINGFACE_API_KEY = import.meta.env.VITE_HUGGINGFACE_API_KEY || ''

export interface HuggingFaceEmotionResult {
  label: string
  score: number
}

export interface AudioEmotionResult {
  emotion: string
  confidence: number
}

export interface FacialEmotionResult {
  emotion: string
  confidence: number
}

export class HuggingFaceService {
  private apiKey: string
  private baseUrl = 'https://api-inference.huggingface.co/models'

  constructor(apiKey: string = HUGGINGFACE_API_KEY) {
    this.apiKey = apiKey
  }

  async callInferenceAPI(modelId: string, payload: any, isImage: boolean = false): Promise<any> {
    if (!this.apiKey || this.apiKey === '') {
      throw new Error('Hugging Face API key not configured')
    }

    const headers: Record<string, string> = {
      'Authorization': `Bearer ${this.apiKey}`,
    }

    if (isImage) {
      // For image data, don't set Content-Type - let browser set it
      headers['Content-Type'] = 'application/octet-stream'
    } else {
      headers['Content-Type'] = 'application/json'
    }

    try {
      const response = await fetch(`${this.baseUrl}/${modelId}`, {
        method: 'POST',
        headers,
        body: isImage ? payload : JSON.stringify(payload)
      })

      if (!response.ok) {
        const errorText = await response.text()
        throw new Error(`Hugging Face API error: ${response.status} - ${errorText}`)
      }

      return await response.json()
    } catch (error) {
      console.error('Hugging Face API Error:', error)
      throw error
    }
  }

  async detectFacialEmotion(imageBlob: Blob): Promise<FacialEmotionResult> {
    try {
      const result = await this.callInferenceAPI(
        'ElenaRyumina/face_emotion_recognition',
        imageBlob,
        true
      )

      // Parse Hugging Face response
      if (Array.isArray(result) && result.length > 0) {
        const topResult = result[0]
        return {
          emotion: this.mapFacialEmotion(topResult.label),
          confidence: topResult.score
        }
      }

      // Fallback if no results
      return {
        emotion: 'neutral',
        confidence: 0.3
      }
    } catch (error) {
      console.error('Facial emotion detection error:', error)
      return {
        emotion: 'neutral',
        confidence: 0.3
      }
    }
  }

  async detectAudioEmotion(audioBlob: Blob): Promise<AudioEmotionResult> {
    try {
      const result = await this.callInferenceAPI(
        'Hatman/audio-emotion-detection',
        audioBlob,
        true
      )

      // Parse Hugging Face response
      if (Array.isArray(result) && result.length > 0) {
        const topResult = result[0]
        return {
          emotion: this.mapAudioEmotion(topResult.label),
          confidence: topResult.score
        }
      }

      // Fallback if no results
      return {
        emotion: 'neutral',
        confidence: 0.3
      }
    } catch (error) {
      console.error('Audio emotion detection error:', error)
      return {
        emotion: 'neutral',
        confidence: 0.3
      }
    }
  }

  private mapFacialEmotion(label: string): string {
    const emotionMap: Record<string, string> = {
      'angry': 'angry',
      'disgust': 'angry',
      'fear': 'anxious',
      'happy': 'happy',
      'sad': 'sad',
      'surprise': 'surprised',
      'neutral': 'neutral',
      'joy': 'happy',
      'excitement': 'excited'
    }

    const lowerLabel = label.toLowerCase()
    return emotionMap[lowerLabel] || 'neutral'
  }

  private mapAudioEmotion(label: string): string {
    const emotionMap: Record<string, string> = {
      'angry': 'angry',
      'calm': 'calm',
      'disgust': 'angry',
      'fearful': 'anxious',
      'happy': 'happy',
      'neutral': 'neutral',
      'sad': 'sad',
      'surprised': 'surprised',
      'excitement': 'excited',
      'joy': 'happy'
    }

    const lowerLabel = label.toLowerCase()
    return emotionMap[lowerLabel] || 'neutral'
  }

  async detectTextEmotion(text: string): Promise<HuggingFaceEmotionResult[]> {
    try {
      const result = await this.callInferenceAPI(
        'j-hartmann/emotion-english-distilroberta-base',
        { inputs: text },
        false
      )

      return Array.isArray(result) ? result : []
    } catch (error) {
      console.error('Text emotion detection error:', error)
      return []
    }
  }
}

export const huggingFaceService = new HuggingFaceService()