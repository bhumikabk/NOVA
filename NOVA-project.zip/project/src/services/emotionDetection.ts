export interface EmotionResult {
  emotion: 'happy' | 'sad' | 'angry' | 'surprised' | 'confused' | 'excited' | 'neutral'
  mood: 'positive' | 'negative' | 'neutral' | 'energetic' | 'calm'
  confidence: number
}

export class TextEmotionDetectionService {
  private emotionKeywords = {
    happy: ['happy', 'joy', 'great', 'awesome', 'wonderful', 'amazing', 'fantastic', 'excellent', 'love', 'excited', 'thrilled', '😊', '😄', '😃', '🙂', '😁', '😆', '🤗', '😍', '🥰', '😘'],
    sad: ['sad', 'depressed', 'down', 'upset', 'disappointed', 'hurt', 'crying', 'tears', 'lonely', 'miserable', '😢', '😭', '😔', '😞', '😟', '🙁', '☹️', '😿', '💔', '😪'],
    angry: ['angry', 'mad', 'furious', 'annoyed', 'frustrated', 'irritated', 'rage', 'hate', 'pissed', 'outraged', '😠', '😡', '🤬', '😤', '💢', '👿', '😾', '🔥'],
    surprised: ['surprised', 'shocked', 'amazed', 'astonished', 'wow', 'incredible', 'unbelievable', 'stunning', '😲', '😮', '😯', '🤯', '😱', '🙀', '😳', '🤭'],
    confused: ['confused', 'puzzled', 'lost', 'unclear', 'uncertain', 'bewildered', 'perplexed', 'baffled', '🤔', '😕', '🤨', '😵‍💫', '🙃', '🤷', '😵'],
    excited: ['excited', 'thrilled', 'pumped', 'energetic', 'enthusiastic', 'eager', 'hyped', 'stoked', '🤩', '😍', '🤗', '🎉', '✨', '🌟', '💫', '🔥', '⚡', '🚀'],
    anxious: ['anxious', 'worried', 'nervous', 'stressed', 'overwhelmed', 'panic', 'fear', 'scared', 'tense', 'uneasy', '😰', '😨', '😟', '😧', '🫨'],
    frustrated: ['frustrated', 'annoyed', 'irritated', 'fed up', 'sick of', 'tired of', 'can\'t stand', 'bothered', '😤', '🙄', '😒', '😠']
  }

  private moodKeywords = {
    positive: ['good', 'great', 'nice', 'wonderful', 'perfect', 'beautiful', 'lovely', 'amazing', 'fantastic'],
    negative: ['bad', 'terrible', 'awful', 'horrible', 'worst', 'hate', 'disgusting', 'annoying'],
    energetic: ['energy', 'active', 'dynamic', 'vibrant', 'lively', 'spirited', 'vigorous'],
    calm: ['calm', 'peaceful', 'relaxed', 'serene', 'tranquil', 'quiet', 'still', 'zen']
  }

  detectEmotion(text: string): EmotionResult {
    const lowerText = text.toLowerCase()
    const words = lowerText.split(/\s+/)
    
    const emotionScores = {
      happy: 0,
      sad: 0,
      angry: 0,
      surprised: 0,
      confused: 0,
      excited: 0,
      anxious: 0,
      frustrated: 0,
      neutral: 0
    }

    const moodScores = {
      positive: 0,
      negative: 0,
      energetic: 0,
      calm: 0,
      neutral: 0
    }

    // Score emotions based on keywords
    for (const [emotion, keywords] of Object.entries(this.emotionKeywords)) {
      for (const keyword of keywords) {
        if (lowerText.includes(keyword)) {
          emotionScores[emotion as keyof typeof emotionScores] += 1
        }
      }
    }

    // Score moods based on keywords
    for (const [mood, keywords] of Object.entries(this.moodKeywords)) {
      for (const keyword of keywords) {
        if (lowerText.includes(keyword)) {
          moodScores[mood as keyof typeof moodScores] += 1
        }
      }
    }

    // Check for question marks (often indicate confusion)
    if (text.includes('?')) {
      emotionScores.confused += 0.5
    }

    // Check for exclamation marks (often indicate excitement or strong emotion)
    const exclamationCount = (text.match(/!/g) || []).length
    if (exclamationCount > 0) {
      emotionScores.excited += exclamationCount * 0.3
      moodScores.energetic += exclamationCount * 0.2
    }

    // Check for capitalization (often indicates strong emotion)
    const capsWords = words.filter(word => word === word.toUpperCase() && word.length > 1)
    if (capsWords.length > 0) {
      emotionScores.excited += capsWords.length * 0.2
      emotionScores.angry += capsWords.length * 0.1
    }

    // Find dominant emotion
    const dominantEmotion = Object.entries(emotionScores).reduce((a, b) => 
      emotionScores[a[0] as keyof typeof emotionScores] > emotionScores[b[0] as keyof typeof emotionScores] ? a : b
    )[0] as keyof typeof emotionScores

    // Find dominant mood
    const dominantMood = Object.entries(moodScores).reduce((a, b) => 
      moodScores[a[0] as keyof typeof moodScores] > moodScores[b[0] as keyof typeof moodScores] ? a : b
    )[0] as keyof typeof moodScores

    // Calculate confidence based on keyword matches
    const totalEmotionScore = Object.values(emotionScores).reduce((sum, score) => sum + score, 0)
    const confidence = Math.min(totalEmotionScore > 0 ? (emotionScores[dominantEmotion] / totalEmotionScore) : 0.3, 1)

    // Default to neutral if no strong emotion detected
    const finalEmotion = totalEmotionScore > 0 ? dominantEmotion : 'neutral'
    const finalMood = Object.values(moodScores).some(score => score > 0) ? dominantMood : 'neutral'

    return {
      emotion: finalEmotion,
      mood: finalMood,
      confidence: Math.max(confidence, 0.3) // Minimum confidence of 30%
    }
  }

  getEmotionEmoji(emotion: string): string {
    const emojiMap = {
      happy: '😊',
      sad: '😔',
      angry: '😤',
      surprised: '😲',
      confused: '🤔',
      excited: '🤩',
      neutral: '😊'
    }
    return emojiMap[emotion as keyof typeof emojiMap] || '😊'
  }
}

export const textEmotionDetectionService = new TextEmotionDetectionService()