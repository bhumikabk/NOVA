import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co'
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key'

export const supabase = createClient(supabaseUrl, supabaseKey)

export type Profile = {
  id: string
  email: string
  full_name: string
  avatar_url?: string
  created_at: string
  updated_at: string
}

export type Conversation = {
  id: string
  user_id: string
  title: string
  messages: Message[]
  created_at: string
  updated_at: string
}

export type Message = {
  id: string
  conversation_id: string
  content: string
  role: 'user' | 'assistant'
  timestamp: string
  message_type: 'text' | 'voice'
}