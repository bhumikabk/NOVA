// ElevenLabs Text-to-Speech Service

export class ElevenLabsService {
  private apiKey: string = import.meta.env.VITE_ELEVENLABS_API_KEY || ''
  private openaiKey: string = import.meta.env.VITE_OPENAI_API_KEY || ''
  private voiceId: string = '21m00Tcm4TlvDq8ikWAM' // Rachel - Calm, soothing female voice perfect for mental wellness
  private currentAudio: HTMLAudioElement | null = null
  private isPlaying: boolean = false

  constructor() {
    // API keys are set from environment variables
  }

  async speak(text: string, onStart?: () => void, onEnd?: () => void): Promise<void> {
    // Stop any currently playing audio
    this.stopSpeaking()

    // Try OpenAI TTS first, then ElevenLabs, then fallback
    if (this.openaiKey && this.openaiKey !== 'your-openai-api-key-here') {
      return this.openAISpeak(text, onStart, onEnd)
    }
    
    if (!this.apiKey || this.apiKey === '' || this.apiKey === 'your-elevenlabs-api-key-here') {
      console.warn('ElevenLabs API key not provided, using fallback TTS')
      return this.fallbackSpeak(text, onStart, onEnd)
    }

    try {
      onStart?.()
      this.isPlaying = true

      const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${this.voiceId}`, {
        method: 'POST',
        headers: {
          'Accept': 'audio/mpeg',
          'Content-Type': 'application/json',
          'xi-api-key': this.apiKey
        },
        body: JSON.stringify({
          text: text,
          model_id: 'eleven_multilingual_v2', // Better for emotional expression
          voice_settings: {
            stability: 0.75, // More stable for calming effect
            similarity_boost: 0.85, // Higher similarity for consistency
            style: 0.6, // Moderate style for natural conversation
            use_speaker_boost: true
          }
        })
      })

      if (!response.ok) {
        const errorText = await response.text()
        console.warn(`ElevenLabs API error: ${response.status} - ${errorText} - falling back to browser TTS`)
        this.isPlaying = false
        onEnd?.()
        return this.fallbackSpeak(text, undefined, onEnd)
      }

      const audioBlob = await response.blob()
      const audioUrl = URL.createObjectURL(audioBlob)
      this.currentAudio = new Audio(audioUrl)
      
      this.currentAudio.volume = 0.8

      this.currentAudio.onended = () => {
        URL.revokeObjectURL(audioUrl)
        this.isPlaying = false
        this.currentAudio = null
        onEnd?.()
      }

      this.currentAudio.onerror = () => {
        URL.revokeObjectURL(audioUrl)
        this.isPlaying = false
        this.currentAudio = null
        onEnd?.()
        console.error('Audio playback error - falling back to browser TTS')
        this.fallbackSpeak(text, undefined, onEnd)
      }

      await this.currentAudio.play()

    } catch (error) {
      console.error('ElevenLabs TTS Error:', error)
      this.isPlaying = false
      onEnd?.()
      // Fallback to browser TTS
      this.fallbackSpeak(text, undefined, onEnd)
    }
  }

  private async openAISpeak(text: string, onStart?: () => void, onEnd?: () => void): Promise<void> {
    try {
      onStart?.()
      this.isPlaying = true

      const response = await fetch('https://api.openai.com/v1/audio/speech', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.openaiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'tts-1',
          input: text,
          voice: 'shimmer', // Warm, caring female voice perfect for mental wellness
          response_format: 'mp3',
          speed: 0.95 // Slightly slower for calming effect
        })
      })

      if (!response.ok) {
        const errorText = await response.text()
        console.warn(`OpenAI TTS API error: ${response.status} - ${errorText} - falling back to browser TTS`)
        this.isPlaying = false
        onEnd?.()
        return this.fallbackSpeak(text, undefined, onEnd)
      }

      const audioBlob = await response.blob()
      const audioUrl = URL.createObjectURL(audioBlob)
      this.currentAudio = new Audio(audioUrl)
      
      this.currentAudio.volume = 0.8

      this.currentAudio.onended = () => {
        URL.revokeObjectURL(audioUrl)
        this.isPlaying = false
        this.currentAudio = null
        onEnd?.()
      }

      this.currentAudio.onerror = () => {
        URL.revokeObjectURL(audioUrl)
        this.isPlaying = false
        this.currentAudio = null
        onEnd?.()
        console.error('OpenAI TTS playback error - falling back to browser TTS')
        this.fallbackSpeak(text, undefined, onEnd)
      }

      await this.currentAudio.play()

    } catch (error) {
      console.error('OpenAI TTS Error:', error)
      this.isPlaying = false
      onEnd?.()
      // Fallback to browser TTS
      this.fallbackSpeak(text, undefined, onEnd)
    }
  }

  private async fallbackSpeak(text: string, onStart?: () => void, onEnd?: () => void): Promise<void> {
    return new Promise((resolve) => {
      // Stop any existing speech
      speechSynthesis.cancel()
      
      this.isPlaying = true
      const utterance = new SpeechSynthesisUtterance(text)
      
      utterance.rate = 0.9
      utterance.pitch = 1.2
      utterance.volume = 0.8

      // Try to get a female voice
      const voices = speechSynthesis.getVoices()
      const femaleVoice = voices.find(voice => 
        voice.name.toLowerCase().includes('female') || 
        voice.name.includes('Samantha') ||
        voice.name.includes('Victoria') ||
        voice.name.includes('Allison') ||
        voice.name.includes('Karen') ||
        (voice.lang.startsWith('en') && voice.name.toLowerCase().includes('google'))
      )
      
      if (femaleVoice) {
        utterance.voice = femaleVoice
      } else {
        // Fallback to any English voice
        const englishVoice = voices.find(voice => voice.lang.startsWith('en'))
        if (englishVoice) {
          utterance.voice = englishVoice
        }
      }

      utterance.onstart = () => onStart?.()
      utterance.onend = () => {
        this.isPlaying = false
        onEnd?.()
        resolve()
      }
      
      utterance.onerror = (event) => {
        // Only log if it's not an interruption (which is normal when stopping)
        if (event.error !== 'interrupted') {
          console.error('Speech synthesis error:', event)
        }
        this.isPlaying = false
        onEnd?.()
        resolve()
      }

      // Add a small delay to prevent rapid speech interruptions
      setTimeout(() => {
        if (this.isPlaying) {
          speechSynthesis.speak(utterance)
        }
      }, 100)
    })
  }

  stopSpeaking() {
    this.isPlaying = false
    
    // Stop HTML5 audio if playing
    if (this.currentAudio) {
      this.currentAudio.pause()
      this.currentAudio.currentTime = 0
      this.currentAudio = null
    }
    
    // Stop speech synthesis
    if (speechSynthesis.speaking) {
      speechSynthesis.speak(utterance)
    }
  }

  isCurrentlySpeaking(): boolean {
    return this.isPlaying || speechSynthesis.speaking
  }
}

export const elevenLabsService = new ElevenLabsService()