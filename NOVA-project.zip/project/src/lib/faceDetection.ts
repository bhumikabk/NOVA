import { huggingFaceService } from '../services/huggingFaceService'

// Enhanced Face Detection Service with Hugging Face Integration
export interface FacialExpression {
  emotion: 'happy' | 'sad' | 'angry' | 'surprised' | 'neutral' | 'excited' | 'confused'
  confidence: number
  mood: 'romantic' | 'funny' | 'serious' | 'playful' | 'calm' | 'energetic'
}

export class FaceDetectionService {
  private isInitialized = false
  private stream: MediaStream | null = null
  private canvas: HTMLCanvasElement | null = null
  private context: CanvasRenderingContext2D | null = null

  async initialize(): Promise<boolean> {
    try {
      // Create canvas for frame capture
      this.canvas = document.createElement('canvas')
      this.canvas.width = 640
      this.canvas.height = 480
      this.context = this.canvas.getContext('2d')
      
      this.isInitialized = true
      return true
    } catch (error) {
      console.error('Failed to initialize face detection:', error)
      return false
    }
  }

  async startVideoStream(): Promise<MediaStream | null> {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'user'
        }
      })
      this.stream = stream
      return stream
    } catch (error) {
      console.error('Error accessing camera:', error)
      return null
    }
  }

  stopVideoStream(stream: MediaStream) {
    stream.getTracks().forEach(track => track.stop())
    this.stream = null
    this.canvas = null
    this.context = null
  }

  async detectEmotion(videoElement?: HTMLVideoElement): Promise<FacialExpression | null> {
    if (!this.isInitialized) {
      return null
    }

    // Try to use Hugging Face for real emotion detection
    if (videoElement && this.canvas && this.context) {
      try {
        // Draw current video frame to canvas
        this.context.drawImage(videoElement, 0, 0, this.canvas.width, this.canvas.height)
        
        // Convert canvas to blob
        const blob = await new Promise<Blob>((resolve) => {
          this.canvas!.toBlob((blob) => {
            resolve(blob!)
          }, 'image/jpeg', 0.8)
        })

        // Send to Hugging Face for emotion detection
        const result = await huggingFaceService.detectFacialEmotion(blob)
        
        return {
          emotion: result.emotion as FacialExpression['emotion'],
          confidence: result.confidence,
          mood: this.mapEmotionToMood(result.emotion)
        }
      } catch (error) {
        console.error('Real emotion detection failed, using fallback:', error)
      }
    }

    // Fallback to time-based simulation
    return this.getFallbackEmotion()
  }

  private getFallbackEmotion(): FacialExpression {
    const hour = new Date().getHours()
    const emotions: FacialExpression['emotion'][] = hour >= 6 && hour < 12 
      ? ['happy', 'neutral', 'excited']
      : hour >= 12 && hour < 18 
      ? ['neutral', 'happy', 'surprised']
      : ['neutral', 'happy']

    const randomEmotion = emotions[Math.floor(Math.random() * emotions.length)]

    return {
      emotion: randomEmotion,
      confidence: 0.6 + Math.random() * 0.4, // 60-100% confidence
      mood: this.mapEmotionToMood(randomEmotion)
    }
  }

  private mapEmotionToMood(emotion: string): FacialExpression['mood'] {
    const moodMap: Record<string, FacialExpression['mood']> = {
      'happy': 'playful',
      'excited': 'energetic',
      'sad': 'calm',
      'angry': 'serious',
      'surprised': 'playful',
      'anxious': 'calm',
      'neutral': 'calm'
    }

    return moodMap[emotion] || 'calm'
  }
}

export const faceDetectionService = new FaceDetectionService()