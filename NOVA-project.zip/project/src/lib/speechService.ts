// Speech Recognition Service
export class SpeechService {
  private recognition: SpeechRecognition | null = null
  private isListening = false

  constructor() {
    this.initializeSpeechRecognition()
  }

  private initializeSpeechRecognition() {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      this.recognition = new SpeechRecognition()
      
      this.recognition.continuous = false
      this.recognition.interimResults = true
      this.recognition.lang = 'en-US'
      this.recognition.maxAlternatives = 1
    }
  }

  async requestMicrophonePermission(): Promise<boolean> {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      stream.getTracks().forEach(track => track.stop())
      return true
    } catch (error) {
      console.error('Microphone permission denied:', error)
      return false
    }
  }

  startListening(
    onResult: (text: string) => void, 
    onError?: (error: string) => void
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.recognition) {
        const error = 'Speech recognition not supported in this browser.'
        onError?.(error)
        reject(new Error(error))
        return
      }

      if (this.isListening) {
        resolve()
        return
      }

      this.isListening = true
      let finalTranscript = ''
      let interimTranscript = ''

      this.recognition.onresult = (event) => {
        interimTranscript = ''
        finalTranscript = ''
        
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript
          
          if (event.results[i].isFinal) {
            finalTranscript += transcript
          } else {
            interimTranscript += transcript
          }
        }

        // Show interim results for better UX
        const currentTranscript = finalTranscript || interimTranscript
        if (currentTranscript && currentTranscript.trim()) {
          onResult(currentTranscript.trim())
          this.isListening = false
          resolve()
        }
      }

      this.recognition.onerror = (event) => {
        let errorMessage = 'Speech recognition error'
        
        switch (event.error) {
          case 'no-speech':
            errorMessage = 'No speech detected. Please try speaking again.'
            break
          case 'audio-capture':
            errorMessage = 'Microphone not accessible.'
            break
          case 'not-allowed':
            errorMessage = 'Microphone permission denied.'
            break
          default:
            errorMessage = `Speech recognition error: ${event.error}`
        }
        
        onError?.(errorMessage)
        this.isListening = false
        reject(new Error(errorMessage))
      }

      this.recognition.onend = () => {
        this.isListening = false
        if (!finalTranscript) {
          resolve()
        }
      }

      try {
        this.recognition.start()
      } catch (error) {
        this.isListening = false
        const errorMessage = 'Failed to start speech recognition'
        onError?.(errorMessage)
        reject(new Error(errorMessage))
      }
    })
  }

  stopListening() {
    if (this.recognition && this.isListening) {
      this.recognition.stop()
      this.isListening = false
    }
  }

  getIsListening(): boolean {
    return this.isListening
  }
}

export const speechService = new SpeechService()