// Emoji Service for Avatar Expressions
export interface EmojiExpression {
  emoji: string
  mood: string
  emotion: string
  intensity: number
}

export class EmojiService {
  private emotionEmojis = {
    // Happy emotions
    happy: ['😊', '😄', '😃', '🙂', '😁', '😆', '🤗', '😍', '🥰', '😘'],
    excited: ['🤩', '😍', '🤗', '🎉', '✨', '🌟', '💫', '🔥', '⚡', '🚀'],
    love: ['😍', '🥰', '😘', '💕', '💖', '💗', '💝', '💘', '💞', '💓'],
    
    // Sad emotions
    sad: ['😢', '😭', '😔', '😞', '😟', '🙁', '☹️', '😿', '💔', '😪'],
    disappointed: ['😞', '😔', '😟', '🙁', '😕', '😒', '😤', '😠', '😡', '🤬'],
    
    // Surprised emotions
    surprised: ['😲', '😮', '😯', '🤯', '😱', '🙀', '😳', '🤭', '😵', '🤪'],
    shocked: ['😱', '🤯', '😵', '😳', '🙀', '😲', '😮', '😯', '🤭', '🫨'],
    
    // Thinking emotions
    thinking: ['🤔', '💭', '🧐', '🤨', '😐', '😑', '🙄', '🤷', '🤯', '💡'],
    confused: ['🤔', '😕', '🤨', '😵‍💫', '🙃', '🤷', '😵', '🫤', '😶', '🤯'],
    
    // Neutral emotions
    neutral: ['😊', '🙂', '😌', '😇', '🤗', '😄', '😃', '😁', '😆', '🥰'],
    calm: ['😌', '😇', '🧘', '☺️', '😊', '🙂', '😴', '😪', '🤗', '💆'],
    
    // Angry emotions
    angry: ['😠', '😡', '🤬', '😤', '💢', '👿', '😾', '🔥', '⚡', '💥'],
    frustrated: ['😤', '😠', '😡', '🙄', '😒', '🤬', '💢', '😾', '👿', '🔥'],
    
    // Playful emotions
    playful: ['😜', '😝', '🤪', '😋', '😛', '🤗', '🎉', '🎊', '🥳', '🤸'],
    silly: ['🤪', '😜', '😝', '😋', '😛', '🙃', '🤡', '🎭', '🎪', '🎨'],
    
    // Romantic emotions
    romantic: ['😍', '🥰', '😘', '💕', '💖', '💗', '💝', '💘', '💞', '💓'],
    flirty: ['😘', '😉', '😏', '🥰', '😍', '💋', '💕', '💖', '🌹', '💐'],
    
    // Energetic emotions
    energetic: ['⚡', '🔥', '💪', '🚀', '🌟', '✨', '💫', '🎯', '🏆', '🎊'],
    motivated: ['💪', '🔥', '⚡', '🚀', '🎯', '🏆', '🌟', '✨', '💫', '🎉']
  }

  private moodEmojis = {
    romantic: ['💕', '💖', '💗', '💝', '💘', '💞', '💓', '🌹', '💐', '🥰'],
    funny: ['😂', '🤣', '😆', '😄', '😃', '😁', '🤪', '😜', '😝', '🎭'],
    serious: ['🤔', '💭', '🧐', '📚', '💼', '🎓', '⚖️', '🔍', '📊', '💡'],
    playful: ['🎮', '🎲', '🎪', '🎨', '🎭', '🎊', '🎉', '🥳', '🤸', '🎯'],
    calm: ['🧘', '☮️', '🕊️', '🌸', '🌺', '🍃', '🌊', '🌙', '⭐', '✨'],
    energetic: ['⚡', '🔥', '💥', '🚀', '🌟', '💫', '🎆', '🎇', '💪', '🏃']
  }

  getEmojiForEmotion(emotion: string, mood: string): string {
    // First try to get emotion-specific emoji
    const emotionEmojis = this.emotionEmojis[emotion as keyof typeof this.emotionEmojis]
    if (emotionEmojis) {
      return emotionEmojis[Math.floor(Math.random() * emotionEmojis.length)]
    }

    // Fallback to mood-based emoji
    const moodEmojis = this.moodEmojis[mood as keyof typeof this.moodEmojis]
    if (moodEmojis) {
      return moodEmojis[Math.floor(Math.random() * moodEmojis.length)]
    }

    // Default fallback
    return '😊'
  }

  getRandomEmojiForMood(mood: string): string {
    const moodEmojis = this.moodEmojis[mood as keyof typeof this.moodEmojis]
    if (moodEmojis) {
      return moodEmojis[Math.floor(Math.random() * moodEmojis.length)]
    }
    return '😊'
  }

  getEmotionIntensity(emotion: string): number {
    const intensityMap = {
      excited: 0.9,
      happy: 0.8,
      love: 0.9,
      surprised: 0.8,
      shocked: 0.9,
      angry: 0.9,
      frustrated: 0.7,
      sad: 0.6,
      disappointed: 0.5,
      thinking: 0.4,
      confused: 0.5,
      neutral: 0.3,
      calm: 0.2,
      playful: 0.7,
      romantic: 0.8,
      energetic: 0.9
    }

    return intensityMap[emotion as keyof typeof intensityMap] || 0.5
  }

  // Get speaking animation emojis
  getSpeakingEmojis(): string[] {
    return ['🗣️', '💬', '🎤', '📢', '🔊', '💭', '💡', '✨']
  }

  // Get listening animation emojis
  getListeningEmojis(): string[] {
    return ['👂', '🎧', '👁️', '👀', '🔍', '📡', '🎯', '⚡']
  }

  // Get thinking animation emojis
  getThinkingEmojis(): string[] {
    return ['🤔', '💭', '🧠', '💡', '⚡', '🔄', '⚙️', '🎯']
  }
}

export const emojiService = new EmojiService()