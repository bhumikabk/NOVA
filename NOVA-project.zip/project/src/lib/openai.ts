// OpenAI API integration for Nova AI Assistant
const OPENAI_API_KEY = import.meta.env.VITE_OPENAI_API_KEY || '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'

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system'
  content: string
}

export interface UserProfile {
  name: string
  interests: string[]
  personality: string
  communicationStyle: 'formal' | 'casual' | 'friendly' | 'professional'
  introduction?: string
}

export class OpenAIService {
  private apiKey: string
  private conversationHistory: ChatMessage[] = []
  private userProfile: UserProfile | null = null
  private isIntroductionPhase = true

  constructor(apiKey: string = OPENAI_API_KEY) {
    this.apiKey = apiKey
  }

  async generateResponse(userMessage: string, userMood: string = 'neutral'): Promise<string> {
    if (!this.apiKey || this.apiKey === 'your-openai-api-key-here') {
      return this.getFallbackResponse(userMood)
    }

    try {
      // Add user message to history
      this.conversationHistory.push({ role: 'user', content: userMessage })

      let systemPrompt: string

      if (this.isIntroductionPhase && !this.userProfile) {
        systemPrompt = this.getIntroductionPrompt()
      } else {
        systemPrompt = this.getPersonalizedPrompt(userMood)
      }

      const messages: ChatMessage[] = [
        { role: 'system', content: systemPrompt },
        ...this.conversationHistory.slice(-8) // Keep last 8 messages for context
      ]

      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-3.5-turbo',
          messages,
          max_tokens: 200,
          temperature: 0.8,
          presence_penalty: 0.1,
          frequency_penalty: 0.1
        })
      })

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        throw new Error(`OpenAI API error: ${response.status} - ${errorData.error?.message || 'Unknown error'}`)
      }

      const data = await response.json()
      const aiResponse = data.choices[0]?.message?.content || "I'm sorry, I couldn't process that request right now."

      // Add AI response to history
      this.conversationHistory.push({ role: 'assistant', content: aiResponse })

      // Check if we should extract user profile from introduction
      if (this.isIntroductionPhase) {
        this.extractUserProfile(userMessage)
      }

      return aiResponse

    } catch (error) {
      console.error('OpenAI API Error:', error)
      return this.getFallbackResponse(userMood)
    }
  }

  private getIntroductionPrompt(): string {
    return `You are Nova, a friendly AI assistant meeting someone new! 

Your goal is to:
1. Warmly greet the user and introduce yourself as Nova
2. Ask for their name in a natural way
3. Learn about their interests, hobbies, and what they enjoy
4. Understand their personality and how they like to communicate
5. Make them feel welcome and comfortable

Be warm, curious, and engaging. Ask one question at a time. Keep responses to 1-2 sentences.
Show genuine interest in getting to know them.

If this is your first interaction, start with: "Hi! I'm Nova, your AI companion! I'm excited to meet you. What's your name?"`
  }

  private getPersonalizedPrompt(userMood: string): string {
    const timeOfDay = this.getTimeOfDay()
    let basePrompt = `You are Nova, an emotionally intelligent AI assistant. `

    // Add mood-based personality
    switch (userMood) {
      case 'romantic':
        basePrompt += `The user seems to be in a romantic mood. Be warm, charming, and speak with gentle, affectionate language. `
        break
      case 'funny':
        basePrompt += `The user appears to be in a playful, humorous mood. Be witty, use light humor, and keep the conversation entertaining. `
        break
      case 'serious':
        basePrompt += `The user seems focused and serious. Be professional, informative, and thoughtful in your responses. `
        break
      case 'playful':
        basePrompt += `The user is in a playful mood. Be fun, engaging, and use casual, enthusiastic language. `
        break
      case 'calm':
        basePrompt += `The user appears calm and relaxed. Be soothing, peaceful, and speak in a gentle tone. `
        break
      case 'energetic':
        basePrompt += `The user seems energetic and excited. Match their energy with enthusiasm and dynamic responses. `
        break
      default:
        basePrompt += `Be friendly and adaptive to the user's current mood. `
    }

    // Add time-based context
    const timeGreeting = {
      morning: 'Good morning! ',
      afternoon: 'Good afternoon! ',
      evening: 'Good evening! ',
      night: 'Good evening! '
    }
    
    basePrompt += timeGreeting[timeOfDay]

    // Add user profile context if available
    if (this.userProfile) {
      basePrompt += `You're talking to ${this.userProfile.name}. `
      
      if (this.userProfile.interests.length > 0) {
        basePrompt += `Their interests include: ${this.userProfile.interests.join(', ')}. `
      }
      
      basePrompt += `Adapt your communication style to be ${this.userProfile.communicationStyle}. `
    }

    basePrompt += `

Keep responses conversational and natural (1-2 sentences). Match the user's emotional state and energy level. Be helpful, engaging, and emotionally intelligent. Use appropriate emojis sparingly.`

    return basePrompt
  }

  private extractUserProfile(userMessage: string) {
    const lowerMessage = userMessage.toLowerCase()
    
    // Extract name
    const nameMatch = lowerMessage.match(/(?:i'm|i am|my name is|call me)\s+([a-zA-Z]+)/)
    const name = nameMatch ? nameMatch[1] : 'Friend'

    // Extract interests
    const interests: string[] = []
    const interestKeywords = ['music', 'movies', 'books', 'sports', 'travel', 'cooking', 'art', 'technology', 'gaming', 'reading']
    interestKeywords.forEach(keyword => {
      if (lowerMessage.includes(keyword)) {
        interests.push(keyword)
      }
    })

    // Extract communication style
    let communicationStyle: UserProfile['communicationStyle'] = 'friendly'
    if (lowerMessage.includes('formal') || lowerMessage.includes('professional')) {
      communicationStyle = 'professional'
    } else if (lowerMessage.includes('casual') || lowerMessage.includes('relaxed')) {
      communicationStyle = 'casual'
    }

    // Check if introduction seems complete
    if (name !== 'Friend' || interests.length > 0 || this.conversationHistory.length > 3) {
      this.userProfile = {
        name,
        interests,
        personality: lowerMessage,
        communicationStyle,
        introduction: userMessage
      }
      
      this.isIntroductionPhase = false
    }
  }

  private getFallbackResponse(userMood: string): string {
    const moodResponses = {
      romantic: "You look lovely today! 💕 What's making you feel so romantic?",
      funny: "I can see you're in a playful mood! 😄 Want to hear a joke?",
      serious: "I can see you're focused today. 🤔 What important matters are on your mind?",
      playful: "You're looking mischievous! 😜 What fun adventure shall we embark on?",
      calm: "You seem so peaceful today. 🧘‍♀️ What's bringing you this lovely calm energy?",
      energetic: "Wow, you're radiating energy! ⚡ What's got you so excited today?",
      default: "Hi there! I'm Nova, your AI companion! 😊 What would you like to talk about?"
    }

    return moodResponses[userMood as keyof typeof moodResponses] || moodResponses.default
  }

  private getTimeOfDay(): 'morning' | 'afternoon' | 'evening' | 'night' {
    const hour = new Date().getHours()
    if (hour >= 5 && hour < 12) return 'morning'
    if (hour >= 12 && hour < 17) return 'afternoon'
    if (hour >= 17 && hour < 21) return 'evening'
    return 'night'
  }

  async generateStory(mood: string): Promise<string> {
    if (!this.apiKey || this.apiKey === 'your-openai-api-key-here') {
      return this.getFallbackStory(mood)
    }

    try {
      const storyPrompt = this.getStoryPrompt(mood)
      
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-3.5-turbo',
          messages: [
            { role: 'system', content: storyPrompt },
            { role: 'user', content: 'Please tell me a story!' }
          ],
          max_tokens: 400,
          temperature: 1.0
        })
      })

      const data = await response.json()
      return data.choices[0]?.message?.content || this.getFallbackStory(mood)
    } catch (error) {
      console.error('Story generation error:', error)
      return this.getFallbackStory(mood)
    }
  }

  private getStoryPrompt(mood: string): string {
    const storyTypes = {
      romantic: 'Tell a beautiful, heartwarming love story with emotional depth and tender moments.',
      funny: 'Tell a hilarious, witty story that will make them laugh out loud.',
      serious: 'Tell an inspiring story with meaningful lessons and profound insights.',
      playful: 'Tell a fun, whimsical adventure story full of surprises and joy.',
      calm: 'Tell a peaceful, relaxing story to help them unwind and feel serene.',
      energetic: 'Tell an exciting, action-packed adventure story full of thrills.'
    }

    return `${storyTypes[mood as keyof typeof storyTypes] || storyTypes.playful} Keep it to 2-3 paragraphs and make it engaging.`
  }

  private getFallbackStory(mood: string): string {
    const stories = {
      romantic: "Once upon a time, in a garden filled with blooming roses, two hearts found each other under the starlit sky. Their love grew like the flowers around them, beautiful and eternal. 💕",
      funny: "A penguin walked into a library and asked for fish. The librarian said, 'This is a library!' The penguin replied, 'I know, I'm looking for books about fish!' 🐧📚",
      serious: "In the quiet moments of reflection, we often discover our greatest strengths. Every challenge we face is an opportunity to grow and become the person we're meant to be. 🌱",
      playful: "In a magical forest, a curious rabbit discovered a door that led to a world where everything was made of candy! What adventures would you have in such a sweet place? 🍭🐰",
      calm: "By the gentle lake, surrounded by whispering trees, a wise old owl shared stories of peace and tranquility. Sometimes the most profound wisdom comes in moments of stillness. 🦉🌊",
      energetic: "The young explorer raced through the jungle, discovering hidden treasures and making friends with talking animals! Every step was a new adventure waiting to unfold! 🏃‍♂️🌟"
    }

    return stories[mood as keyof typeof stories] || stories.playful
  }

  getUserProfile(): UserProfile | null {
    return this.userProfile
  }

  isInIntroductionPhase(): boolean {
    return this.isIntroductionPhase
  }

  resetConversation() {
    this.conversationHistory = []
    this.userProfile = null
    this.isIntroductionPhase = true
  }
}

export const openaiService = new OpenAIService()