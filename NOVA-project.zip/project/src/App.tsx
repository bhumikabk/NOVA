import React from 'react';
import DashboardPage from './pages/DashboardPage';

export default function App() {
  return <DashboardPage />;
}