import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Mic, 
  MicOff, 
  VolumeX, 
  Send, 
  Menu,
  User,
  Settings,
  History,
  HelpCircle,
  MessageSquare,
  Volume2,
  Eye,
  EyeOff
} from 'lucide-react'
import toast from 'react-hot-toast'
import EmojiAvatar from '../components/Avatar/EmojiAvatar'
import FaceDetectionCamera from '../components/Camera/FaceDetectionCamera'
import { aiModelService } from '../services/aiModels'
import { novaPersonality } from '../services/novaPersonality'
import { speechService } from '../lib/speechService'
import { elevenLabsService } from '../lib/elevenLabsService'
import { textEmotionDetectionService } from '../services/emotionDetection'

interface Message {
  id: string
  content: string
  role: 'user' | 'assistant'
  timestamp: string
  type: 'text' | 'voice'
  emotion?: any
}

export default function DashboardPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [activeSection, setActiveSection] = useState('chat')
  const [messages, setMessages] = useState<Message[]>([])
  const [inputText, setInputText] = useState('')
  const [isListening, setIsListening] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [isThinking, setIsThinking] = useState(false)
  const [hasPermissions, setHasPermissions] = useState(false)
  const [currentUserEmotion, setCurrentUserEmotion] = useState({
    emotion: 'neutral',
    confidence: 0.5,
    mood: 'calm'
  })
  const [cameraEnabled, setCameraEnabled] = useState(false)
  const [avatarStyle, setAvatarStyle] = useState<'professional' | 'friendly' | 'casual'>('friendly')

  // Initialize with welcome message
  useEffect(() => {
    initializeNova()
  }, [])

  const initializeNova = async () => {
    // Only show introduction if not already completed
    if (!novaPersonality.isIntroductionComplete()) {
      const welcomeMessage: Message = {
        id: '1',
        content: novaPersonality.getIntroductionMessage(),
        role: 'assistant',
        timestamp: new Date().toISOString(),
        type: 'text',
        emotion: { emotion: 'happy', confidence: 0.9, mood: 'calm' }
      }
      setMessages([welcomeMessage])
      
      // Speak welcome message with ElevenLabs
      setTimeout(() => {
        setIsSpeaking(true)
        elevenLabsService.speak(
          welcomeMessage.content,
          () => setIsSpeaking(true),
          () => setIsSpeaking(false)
        )
      }, 1000)
    } else {
      // User already introduced, show a brief greeting
      const greetingMessage: Message = {
        id: '1',
        content: `Welcome back${novaPersonality.userName ? `, ${novaPersonality.userName}` : ''}! How are you feeling today? 😊`,
        role: 'assistant',
        timestamp: new Date().toISOString(),
        type: 'text',
        emotion: { emotion: 'happy', confidence: 0.8, mood: 'calm' }
      }
      setMessages([greetingMessage])
    }
  }

  const handleEmotionDetected = (emotion: any) => {
    setCurrentUserEmotion(emotion)
    
    // Update avatar style based on user's mood
    switch (emotion.mood) {
      case 'romantic':
      case 'serious':
        setAvatarStyle('professional')
        break
      case 'funny':
      case 'playful':
        setAvatarStyle('casual')
        break
      default:
        setAvatarStyle('friendly')
    }
  }

  const initializePermissions = async () => {
    try {
      const micPermission = await speechService.requestMicrophonePermission()
      if (micPermission) {
        setHasPermissions(true)
        toast.success('🎤 Microphone ready!')
      } else {
        toast.error('Microphone access denied.')
      }
    } catch (error) {
      console.error('Permission error:', error)
      toast.error('Could not access microphone.')
    }
  }

  const handleSendMessage = async (content: string, type: 'text' | 'voice') => {
    if (!content.trim()) return

    // Detect user's emotional state from their message
    const detectedEmotion = textEmotionDetectionService.detectEmotion(content)
    const userMood = {
      primary: detectedEmotion.emotion,
      confidence: detectedEmotion.confidence
    }

    // Extract and set user name if this is the first interaction
    const nameMatch = content.toLowerCase().match(/(?:i'm|i am|my name is|call me|i'm called)\s+([a-zA-Z]+)/)
    if (nameMatch && nameMatch[1]) {
      const extractedName = nameMatch[1].charAt(0).toUpperCase() + nameMatch[1].slice(1)
      novaPersonality.setUserName(extractedName)
    }

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content,
      role: 'user',
      timestamp: new Date().toISOString(),
      type,
      emotion: { 
        emotion: detectedEmotion.emotion, 
        confidence: detectedEmotion.confidence, 
        mood: detectedEmotion.mood 
      }
    }

    setMessages(prev => [...prev, userMessage])

    // Show thinking state
    setIsThinking(true)
    
    try {
      // Generate AI response with Nova's personality
      const aiResponseText = await aiModelService.generateResponse(content, userMood, messages.slice(-4), novaPersonality.userName)
      
      setIsThinking(false)
      
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: aiResponseText,
        role: 'assistant',
        timestamp: new Date().toISOString(),
        type: 'text',
        emotion: { 
          emotion: 'supportive', 
          confidence: 0.8, 
          mood: 'calm' 
        }
      }

      setMessages(prev => [...prev, aiResponse])
      
      // Speak the response with ElevenLabs
      setIsSpeaking(true)
      await elevenLabsService.speak(
        aiResponseText,
        () => setIsSpeaking(true),
        () => setIsSpeaking(false)
      )
      
    } catch (error) {
      console.error('Error generating response:', error)
      setIsThinking(false)
      setIsSpeaking(false)
      
      const errorResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: "I'm having some technical difficulties right now, but I'm still here for you! How are you feeling today? 💙",
        role: 'assistant',
        timestamp: new Date().toISOString(),
        type: 'text',
        emotion: { emotion: 'supportive', confidence: 0.7, mood: 'calm' }
      }
      
      setMessages(prev => [...prev, errorResponse])
      toast.error('Having trouble connecting, but I\'m still here for you!')
    }
  }

  const handleRequestStory = async () => {
    setIsThinking(true)
    
    try {
      const story = await openaiService.generateStory(currentUserEmotion.mood)
      
      const storyMessage: Message = {
        id: Date.now().toString(),
        content: story,
        role: 'assistant',
        timestamp: new Date().toISOString(),
        type: 'text',
        emotion: { emotion: 'excited', confidence: 0.9, mood: currentUserEmotion.mood }
      }
      
      setMessages(prev => [...prev, storyMessage])
      setIsThinking(false)
      
      // Speak the story with ElevenLabs
      setIsSpeaking(true)
      await elevenLabsService.speak(
        story,
        () => setIsSpeaking(true),
        () => setIsSpeaking(false)
      )
    } catch (error) {
      setIsThinking(false)
      toast.error('Could not generate story right now')
    }
  }

  const handleToggleListening = async () => {
    if (!hasPermissions) {
      await initializePermissions()
      return
    }

    if (isListening) {
      speechService.stopListening()
      setIsListening(false)
      return
    }

    setIsListening(true)
    
    try {
      await speechService.startListening(
        (transcript) => {
          setIsListening(false)
          if (transcript.trim()) {
            handleSendMessage(transcript, 'voice')
          }
        },
        (error) => {
          setIsListening(false)
          console.error('Speech recognition error:', error)
          toast.error('Could not understand speech.')
        }
      )
    } catch (error) {
      setIsListening(false)
      console.error('Speech recognition failed:', error)
      toast.error('Speech recognition failed.')
    }
  }
  
  const handleAvatarClick = async () => {
    if (!hasPermissions) {
      await initializePermissions()
      return
    }

    if (!isListening && !isSpeaking && !isThinking) {
      handleToggleListening()
    }
  }

  const handleStopSpeaking = () => {
    if (elevenLabsService.isCurrentlySpeaking()) {
      elevenLabsService.stopSpeaking()
      setIsSpeaking(false)
    }
  }

  const handleToggleCamera = () => {
    setCameraEnabled(!cameraEnabled)
    if (!cameraEnabled) {
      toast.success('📷 Camera enabled! Nova can now see your emotions.')
    } else {
      toast('📷 Camera disabled.')
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!inputText.trim()) return
    handleSendMessage(inputText.trim(), 'text')
    setInputText('')
  }

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    })
  }

  const menuItems = [
    { id: 'chat', label: 'Chat', icon: MessageSquare },
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'history', label: 'History', icon: History },
    { id: 'settings', label: 'Settings', icon: Settings },
    { id: 'help', label: 'Help & Support', icon: HelpCircle },
  ]

  const getSectionTitle = () => {
    switch (activeSection) {
      case 'chat': return 'Nova AI Assistant'
      case 'profile': return 'Your Profile'
      case 'history': return 'Conversation History'
      case 'settings': return 'Settings'
      case 'help': return 'Help & Support'
      default: return 'Nova Dashboard'
    }
  }

  const renderMainContent = () => {
    if (activeSection !== 'chat') {
      return (
        <div className="flex items-center justify-center h-full">
          <div className="text-center text-white">
            <h2 className="text-2xl font-bold mb-4">{getSectionTitle()}</h2>
            <p className="text-gray-300">This section is coming soon!</p>
          </div>
        </div>
      )
    }

    return (
      <div className="flex flex-col lg:flex-row h-full gap-6 p-6">
        {/* Avatar Section */}
        <div className="lg:w-1/2 flex flex-col items-center justify-center min-h-[400px] lg:min-h-0">
          <EmojiAvatar
            isListening={isListening}
            isSpeaking={isSpeaking}
            isThinking={isThinking}
            avatarStyle={avatarStyle}
            onAvatarClick={handleAvatarClick}
            userEmotion={currentUserEmotion}
          />
          
          {/* Quick Controls */}
          <div className="flex items-center gap-4 mt-8">
            {/* Camera Toggle */}
            <FaceDetectionCamera
              onEmotionDetected={handleEmotionDetected}
              isEnabled={cameraEnabled}
              onToggle={handleToggleCamera}
            />

            {/* Microphone Toggle */}
            <motion.button
              onClick={handleToggleListening}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              disabled={!hasPermissions && !isListening}
              className={`p-4 rounded-full backdrop-blur-sm border transition-all duration-200 ${
                isListening 
                  ? 'bg-red-500/20 border-red-500/30 text-red-400' 
                  : hasPermissions
                  ? 'bg-blue-500/20 border-blue-500/30 text-blue-400 hover:bg-blue-500/30'
                  : 'bg-gray-500/20 border-gray-500/30 text-gray-500 cursor-not-allowed'
              }`}
            >
              {isListening ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
            </motion.button>

            {/* Stop Speaking */}
            {isSpeaking && (
              <motion.button
                onClick={handleStopSpeaking}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="p-4 rounded-full bg-purple-500/20 border border-purple-500/30 text-purple-400 hover:bg-purple-500/30 transition-all duration-200"
              >
                <VolumeX className="w-6 h-6" />
              </motion.button>
            )}

            {/* Enable Permissions */}
            {!hasPermissions && (
              <motion.button
                onClick={initializePermissions}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-4 py-2 bg-green-500/20 border border-green-500/30 text-green-400 rounded-lg hover:bg-green-500/30 transition-all duration-200 text-sm"
              >
                Enable Voice
              </motion.button>
            )}

            {/* Story Request */}
            <motion.button
              onClick={handleRequestStory}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              disabled={isThinking || isSpeaking}
              className="px-4 py-2 bg-purple-500/20 border border-purple-500/30 text-purple-400 rounded-lg hover:bg-purple-500/30 transition-all duration-200 text-sm disabled:opacity-50"
            >
              Tell Story
            </motion.button>
          </div>

          {/* Emotion Status */}
          {cameraEnabled && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-6 text-center"
            >
              <div className="bg-white/10 backdrop-blur-sm rounded-xl px-6 py-3 border border-white/20">
                <p className="text-white/90 text-sm">
                  Detected: {' '}
                  <span className="font-semibold text-blue-400">
                    {currentUserEmotion.emotion}
                  </span>
                  {' '}mood: {' '}
                  <span className="font-semibold text-purple-400">
                    {currentUserEmotion.mood}
                  </span>
                </p>
              </div>
            </motion.div>
          )}
        </div>

        {/* Chat Section */}
        <div className="lg:w-1/2 bg-white/5 backdrop-blur-lg rounded-2xl border border-white/20 overflow-hidden flex flex-col">
          {/* Chat Header */}
          <div className="p-4 border-b border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-white font-semibold">Chat with Nova</h3>
                <p className="text-gray-400 text-sm">
                  Your mental wellness companion
                </p>
              </div>
              <div className="text-right">
                <div className="text-xs text-gray-400">
                  {cameraEnabled ? '👁️ Emotion-aware mode' : '💙 Supportive mode'}
                </div>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 max-h-[500px]">
            <AnimatePresence>
              {messages.map((message, index) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl ${
                    message.role === 'user'
                      ? `bg-gradient-to-br ${
                          message.emotion?.mood === 'romantic' ? 'from-pink-500 to-red-600' :
                          message.emotion?.mood === 'funny' ? 'from-yellow-500 to-orange-600' :
                          message.emotion?.mood === 'serious' ? 'from-gray-600 to-blue-700' :
                          message.emotion?.mood === 'playful' ? 'from-purple-500 to-pink-600' :
                          message.emotion?.mood === 'energetic' ? 'from-green-500 to-teal-600' :
                          'from-blue-500 to-purple-600'
                        } text-white`
                      : `bg-gradient-to-br ${
                          message.emotion?.mood === 'romantic' ? 'from-pink-500/20 to-red-600/20 border-pink-500/30' :
                          message.emotion?.mood === 'funny' ? 'from-yellow-500/20 to-orange-600/20 border-yellow-500/30' :
                          message.emotion?.mood === 'serious' ? 'from-gray-600/20 to-blue-700/20 border-gray-500/30' :
                          message.emotion?.mood === 'playful' ? 'from-purple-500/20 to-pink-600/20 border-purple-500/30' :
                          message.emotion?.mood === 'energetic' ? 'from-green-500/20 to-teal-600/20 border-green-500/30' :
                          'from-white/10 to-white/5 border-white/20'
                        } backdrop-blur-sm border text-white`
                  }`}>
                    <p className="text-sm leading-relaxed">{message.content}</p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs opacity-70">
                        {formatTime(message.timestamp)}
                      </span>
                      <div className="flex items-center gap-2 text-xs opacity-70">
                        {message.type === 'voice' && (
                          <div className="flex items-center gap-1">
                            <Volume2 className="w-3 h-3" />
                            Voice
                          </div>
                        )}
                        {message.emotion && (
                          <div className="flex items-center gap-1">
                            <span>{
                              message.emotion.emotion === 'happy' ? '😊' :
                              message.emotion.emotion === 'sad' ? '😔' :
                              message.emotion.emotion === 'angry' ? '😤' :
                              message.emotion.emotion === 'surprised' ? '😲' :
                              message.emotion.emotion === 'excited' ? '🤩' :
                              message.emotion.emotion === 'confused' ? '🤨' :
                              '😊'
                            }</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {isThinking && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex justify-start"
              >
                <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl px-4 py-3">
                  <div className="flex items-center gap-1">
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 0.6, repeat: Infinity, delay: 0 }}
                      className="w-2 h-2 bg-white/60 rounded-full"
                    />
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 0.6, repeat: Infinity, delay: 0.2 }}
                      className="w-2 h-2 bg-white/60 rounded-full"
                    />
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 0.6, repeat: Infinity, delay: 0.4 }}
                      className="w-2 h-2 bg-white/60 rounded-full"
                    />
                  </div>
                  <p className="text-xs text-white/70 mt-1">
                    Nova is thinking...
                  </p>
                </div>
              </motion.div>
            )}
          </div>

          {/* Input Section */}
          <div className="p-4 border-t border-white/10">
            <form onSubmit={handleSubmit} className="flex items-center gap-3">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={
                  !novaPersonality.userName ? 
                  "Tell me your name and how you're feeling..." : 
                  "Share what's on your mind..."
                }
                className="flex-1 px-4 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
              />
              <motion.button
                type="submit"
                disabled={!inputText.trim()}
                whileHover={{ scale: inputText.trim() ? 1.1 : 1 }}
                whileTap={{ scale: inputText.trim() ? 0.9 : 1 }}
                className={`p-3 rounded-xl text-white disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 ${
                  currentUserEmotion.mood === 'romantic' ? 'bg-gradient-to-br from-pink-500 to-red-600 hover:from-pink-600 hover:to-red-700' :
                  currentUserEmotion.mood === 'funny' ? 'bg-gradient-to-br from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700' :
                  currentUserEmotion.mood === 'serious' ? 'bg-gradient-to-br from-gray-600 to-blue-700 hover:from-gray-700 hover:to-blue-800' :
                  currentUserEmotion.mood === 'playful' ? 'bg-gradient-to-br from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700' :
                  currentUserEmotion.mood === 'energetic' ? 'bg-gradient-to-br from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700' :
                  'bg-gradient-to-br from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700'
                }`}
              >
                <Send className="w-5 h-5" />
              </motion.button>
            </form>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          animate={{
            rotate: [0, 360],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 30,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute -top-40 -right-40 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            rotate: [360, 0],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 40,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl"
        />
      </div>

      {/* Sidebar */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden"
              onClick={() => setSidebarOpen(false)}
            />

            {/* Sidebar */}
            <motion.div
              initial={{ x: -320 }}
              animate={{ x: 0 }}
              exit={{ x: -320 }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed left-0 top-0 h-full w-80 bg-white/5 backdrop-blur-xl border-r border-white/20 z-50 overflow-y-auto"
            >
              {/* Header */}
              <div className="p-6 border-b border-white/10">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
                    N
                  </div>
                  <div>
                    <h3 className="text-white font-semibold">
                      {novaPersonality.userName || 'Nova User'}
                    </h3>
                    <p className="text-gray-400 text-sm">
                      {!novaPersonality.userName ? 
                        'Getting acquainted...' : 
                        `Feeling ${currentUserEmotion.emotion} today`
                      }
                    </p>
                  </div>
                </div>
              </div>

              {/* Navigation */}
              <nav className="p-4 space-y-2">
                {menuItems.map((item) => {
                  const Icon = item.icon
                  const isActive = activeSection === item.id

                  return (
                    <motion.button
                      key={item.id}
                      onClick={() => {
                        setActiveSection(item.id)
                        if (window.innerWidth < 1024) setSidebarOpen(false)
                      }}
                      whileHover={{ x: 4 }}
                      whileTap={{ scale: 0.98 }}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all duration-200 ${
                        isActive
                          ? 'bg-gradient-to-r from-blue-500/20 to-purple-600/20 border border-blue-500/30 text-white'
                          : 'text-gray-300 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="font-medium">{item.label}</span>
                    </motion.button>
                  )
                })}
              </nav>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="flex flex-col h-screen">
        {/* Header */}
        <motion.header
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="flex items-center justify-between px-6 py-4 bg-white/5 backdrop-blur-xl border-b border-white/10"
        >
          <div className="flex items-center gap-4">
            <motion.button
              onClick={() => setSidebarOpen(true)}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white transition-colors duration-200"
            >
              <Menu className="w-6 h-6" />
            </motion.button>
            
            <div>
              <h1 className="text-xl font-bold text-white">{getSectionTitle()}</h1>
              {cameraEnabled && (
                <p className="text-sm text-gray-300">
                  Emotion-aware mode • {currentUserEmotion.emotion} • {currentUserEmotion.mood}
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-white text-xs">
              {cameraEnabled ? '👁️ Seeing' : '😊 Default'}
            </div>
            <div className="text-white text-sm">
              <span className="text-green-400">✅ AI Ready</span>
            </div>
          </div>
        </motion.header>

        <main className="flex-1 overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeSection}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="h-full"
            >
              {renderMainContent()}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  )
}