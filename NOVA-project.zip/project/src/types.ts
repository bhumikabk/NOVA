export interface Message {
  id: string
  content: string
  role: 'user' | 'assistant'
  timestamp: string
  type: 'text' | 'voice'
  emotion?: {
    emotion: string
    mood: string
    confidence: number
  }
}

export interface EmotionContext {
  emotion: string
  mood: string
  confidence: number
}