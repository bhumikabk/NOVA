import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { emotionDetectionService } from '../services/emotionDetection'

interface AvatarProps {
  isListening: boolean
  isSpeaking: boolean
  isThinking: boolean
  currentEmotion?: {
    emotion: string
    mood: string
    confidence: number
  }
  onAvatarClick?: () => void
}

export default function Avatar({ 
  isListening, 
  isSpeaking, 
  isThinking, 
  currentEmotion,
  onAvatarClick 
}: AvatarProps) {
  const [displayEmoji, setDisplayEmoji] = useState('😊')
  const [lastEmotionTime, setLastEmotionTime] = useState(0)

  // Only update emoji when emotion actually changes or during specific states
  useEffect(() => {
    let newEmoji = '😊' // Default neutral emoji

    // Priority 1: Active states (thinking, listening, speaking)
    if (isThinking) {
      newEmoji = '🤔'
    } else if (isListening) {
      newEmoji = '👂'
    } else if (isSpeaking) {
      newEmoji = '🗣️'
    } 
    // Priority 2: Emotion-based (only if emotion is recent and confident)
    else if (currentEmotion && currentEmotion.confidence > 0.5) {
      const now = Date.now()
      // Only update if this is a new emotion detection (within last 5 seconds)
      if (now - lastEmotionTime < 5000) {
        newEmoji = textEmotionDetectionService.getEmotionEmoji(currentEmotion.emotion)
      }
    }

    setDisplayEmoji(newEmoji)
  }, [isListening, isSpeaking, isThinking, currentEmotion, lastEmotionTime])

  // Track when new emotions are detected
  useEffect(() => {
    if (currentEmotion) {
      setLastEmotionTime(Date.now())
    }
  }, [currentEmotion?.emotion]) // Only trigger when emotion actually changes

  const getGradientColors = () => {
    if (currentEmotion) {
      switch (currentEmotion.emotion) {
        case 'happy': return 'from-yellow-400 via-orange-500 to-red-500'
        case 'sad': return 'from-blue-600 via-blue-700 to-indigo-800'
        case 'angry': return 'from-red-500 via-red-600 to-red-700'
        case 'surprised': return 'from-purple-400 via-pink-500 to-red-500'
        case 'confused': return 'from-gray-500 via-gray-600 to-gray-700'
        case 'excited': return 'from-green-400 via-teal-500 to-blue-500'
        default: return 'from-blue-400 via-teal-500 to-green-500'
      }
    }
    return 'from-blue-400 via-teal-500 to-green-500'
  }

  const avatarVariants = {
    idle: {
      scale: 1,
      rotate: 0,
      y: [0, -8, 0],
      transition: {
        y: { duration: 4, repeat: Infinity, ease: "easeInOut" },
        scale: { duration: 0.3 },
        rotate: { duration: 0.3 }
      }
    },
    listening: {
      scale: [1, 1.1, 1],
      rotate: [-2, 2, -2, 0],
      transition: {
        duration: 1.5,
        repeat: Infinity,
        ease: "easeInOut"
      }
    },
    speaking: {
      scale: [1, 1.05, 1],
      y: [-2, 0, -2],
      transition: {
        duration: 0.6,
        repeat: Infinity,
        ease: "easeInOut"
      }
    },
    thinking: {
      scale: [1, 1.02, 1],
      rotate: [-1, 1, -1, 0],
      transition: {
        duration: 2,
        repeat: Infinity,
        ease: "easeInOut"
      }
    }
  }

  return (
    <div className="relative flex flex-col items-center">
      {/* Outer Glow Effect */}
      <motion.div
        animate={{
          scale: isListening ? [1, 1.4, 1] : isSpeaking ? [1, 1.2, 1] : isThinking ? [1, 1.3, 1] : [1, 1.1, 1],
          opacity: isListening ? [0.3, 0.8, 0.3] : isSpeaking ? [0.4, 0.9, 0.4] : isThinking ? [0.2, 0.7, 0.2] : [0.2, 0.5, 0.2],
        }}
        transition={{
          duration: isListening ? 1.5 : isSpeaking ? 0.8 : isThinking ? 2.5 : 3,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className={`absolute w-96 h-96 rounded-full bg-gradient-to-br ${getGradientColors()} blur-2xl`}
      />

      {/* Main Avatar Container */}
      <motion.div
        variants={avatarVariants}
        animate={
          isSpeaking ? 'speaking' : 
          isListening ? 'listening' : 
          isThinking ? 'thinking' : 
          'idle'
        }
        onClick={onAvatarClick}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="relative cursor-pointer"
      >
        {/* Avatar Circle */}
        <div className="relative w-80 h-80 rounded-full bg-gradient-to-br from-white/20 to-white/5 backdrop-blur-lg border-2 border-white/30 shadow-2xl overflow-hidden">
          
          {/* Background Gradient */}
          <div className={`absolute inset-0 bg-gradient-to-br ${getGradientColors()} opacity-60`} />
          
          {/* Emoji Face - Only changes based on actual states/emotions */}
          <div className="absolute inset-0 flex items-center justify-center">
            <AnimatePresence mode="wait">
              <motion.div
                key={displayEmoji}
                initial={{ scale: 0, rotate: -180, opacity: 0 }}
                animate={{ 
                  scale: 1, 
                  rotate: 0, 
                  opacity: 1
                }}
                exit={{ scale: 0, rotate: 180, opacity: 0 }}
                transition={{ 
                  duration: 0.5, 
                  ease: "backOut"
                }}
                className="text-9xl select-none"
              >
                {displayEmoji}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* State-specific effects */}
          {isListening && (
            <motion.div
              animate={{
                opacity: [0, 0.6, 0],
                scale: [0.8, 1.5, 0.8],
              }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              className="absolute inset-0 bg-gradient-to-r from-blue-400/30 via-transparent to-blue-400/30 rounded-full"
            />
          )}

          {isSpeaking && (
            <>
              <motion.div
                animate={{
                  opacity: [0.2, 0.8, 0.2],
                  scale: [1, 1.2, 1],
                }}
                transition={{ duration: 0.6, repeat: Infinity, ease: "easeInOut" }}
                className="absolute inset-0 bg-gradient-to-br from-purple-400/40 to-pink-500/40 rounded-full"
              />
              {/* Sound waves */}
              {[...Array(3)].map((_, i) => (
                <motion.div
                  key={i}
                  animate={{
                    scale: [1, 1.5, 1],
                    opacity: [0, 0.5, 0]
                  }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    delay: i * 0.3,
                    ease: "easeOut"
                  }}
                  className="absolute inset-0 border-2 border-white/30 rounded-full"
                />
              ))}
            </>
          )}

          {isThinking && (
            <motion.div
              animate={{
                opacity: [0.1, 0.5, 0.1],
                scale: [1, 1.3, 1],
                rotate: [0, 180, 360]
              }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              className="absolute inset-0 bg-gradient-to-br from-yellow-400/30 via-orange-500/30 to-red-500/30 rounded-full"
            />
          )}
        </div>
      </motion.div>

      {/* Status Indicators */}
      <AnimatePresence>
        {isListening && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.5 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.5 }}
            className="absolute -bottom-8 left-1/2 -translate-x-1/2 px-6 py-3 bg-blue-500/90 text-white text-lg font-medium rounded-full backdrop-blur-sm border border-blue-400/50 flex items-center gap-3"
          >
            <motion.div
              animate={{ scale: [1, 1.3, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
              className="text-xl"
            >
              🎤
            </motion.div>
            I'm listening...
          </motion.div>
        )}

        {isSpeaking && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.5 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.5 }}
            className="absolute -bottom-8 left-1/2 -translate-x-1/2 px-6 py-3 bg-purple-500/90 text-white text-lg font-medium rounded-full backdrop-blur-sm border border-purple-400/50 flex items-center gap-3"
          >
            <motion.div
              animate={{ scale: [1, 1.4, 1] }}
              transition={{ duration: 0.5, repeat: Infinity }}
              className="text-xl"
            >
              🔊
            </motion.div>
            Speaking...
          </motion.div>
        )}

        {isThinking && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.5 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.5 }}
            className="absolute -bottom-8 left-1/2 -translate-x-1/2 px-6 py-3 bg-yellow-500/90 text-white text-lg font-medium rounded-full backdrop-blur-sm border border-yellow-400/50 flex items-center gap-3"
          >
            <motion.div
              animate={{ rotate: [0, 360] }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              className="text-xl"
            >
              💭
            </motion.div>
            Thinking...
          </motion.div>
        )}
      </AnimatePresence>

      {/* Emotion Display */}
      {currentEmotion && currentEmotion.confidence > 0.5 && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mt-8 text-center"
        >
          <div className="bg-white/10 backdrop-blur-sm rounded-xl px-4 py-2 border border-white/20">
            <p className="text-white/80 text-sm">
              Detected: {' '}
              <span className="font-semibold text-white">
                {currentEmotion.emotion}
              </span>
              {' '}({Math.round(currentEmotion.confidence * 100)}% confident)
            </p>
          </div>
        </motion.div>
      )}

      {/* Interactive Hint */}
      {!isListening && !isSpeaking && !isThinking && (
        <motion.div
          animate={{ y: [0, -8, 0], opacity: [0.6, 1, 0.6] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          className="mt-12 text-center"
        >
          <p className="text-white/70 text-lg font-medium mb-2">
            Hi! I'm Nova, your AI companion
          </p>
          <p className="text-white/50 text-sm">
            Click me to start talking or type a message below!
          </p>
        </motion.div>
      )}
    </div>
  )
}