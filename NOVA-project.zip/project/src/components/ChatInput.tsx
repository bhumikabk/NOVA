import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Send } from 'lucide-react'

interface ChatInputProps {
  onSendMessage: (message: string, type?: 'text' | 'voice') => void
  disabled?: boolean
  placeholder?: string
}

export default function ChatInput({ 
  onSendMessage, 
  disabled = false, 
  placeholder = "Type your message..." 
}: ChatInputProps) {
  const [inputText, setInputText] = useState('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!inputText.trim() || disabled) return
    
    onSendMessage(inputText.trim(), 'text')
    setInputText('')
  }

  return (
    <div className="p-4 border-t border-white/10">
      <form onSubmit={handleSubmit} className="flex items-center gap-3">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={placeholder}
          disabled={disabled}
          className="flex-1 px-4 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 disabled:opacity-50"
        />
        <motion.button
          type="submit"
          disabled={!inputText.trim() || disabled}
          whileHover={{ scale: inputText.trim() && !disabled ? 1.1 : 1 }}
          whileTap={{ scale: inputText.trim() && !disabled ? 0.9 : 1 }}
          className="p-3 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
        >
          <Send className="w-5 h-5" />
        </motion.button>
      </form>
    </div>
  )
}