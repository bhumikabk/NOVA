import React, { useRef, useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Camera, Eye, EyeOff } from 'lucide-react'
import { faceDetectionService } from '../../lib/faceDetection'

interface FaceDetectionCameraProps {
  onEmotionDetected: (emotion: any) => void
  isEnabled: boolean
  onToggle: () => void
}

export default function FaceDetectionCamera({ 
  onEmotionDetected, 
  isEnabled, 
  onToggle 
}: FaceDetectionCameraProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [isInitialized, setIsInitialized] = useState(false)
  const [lastEmotion, setLastEmotion] = useState<any>(null)

  useEffect(() => {
    if (isEnabled) {
      initializeCamera()
    } else {
      stopCamera()
    }

    return () => stopCamera()
  }, [isEnabled])

  const initializeCamera = async () => {
    try {
      const initialized = await faceDetectionService.initialize()
      if (!initialized) {
        console.error('Failed to initialize face detection')
        return
      }

      const videoStream = await faceDetectionService.startVideoStream()
      if (!videoStream) {
        console.error('Failed to start video stream')
        return
      }

      setStream(videoStream)
      
      if (videoRef.current) {
        videoRef.current.srcObject = videoStream
        videoRef.current.play()
        setIsInitialized(true)
        
        // Wait for video to be ready before starting emotion detection
        videoRef.current.onloadedmetadata = () => {
          startEmotionDetection()
        }
      }
    } catch (error) {
      console.error('Error initializing camera:', error)
    }
  }

  const stopCamera = () => {
    if (stream) {
      faceDetectionService.stopVideoStream(stream)
      setStream(null)
    }
    setIsInitialized(false)
  }

  const startEmotionDetection = () => {
    if (!isInitialized || !videoRef.current) return
    
    const detectEmotion = async () => {
      if (!isEnabled) return

      try {
        const emotion = await faceDetectionService.detectEmotion(videoRef.current!)
        if (emotion) {
          setLastEmotion(emotion)
          onEmotionDetected(emotion)
        }
      } catch (error) {
        console.error('Error detecting emotion:', error)
      }

      if (isEnabled) {
        setTimeout(detectEmotion, 3000) // Detect every 3 seconds to avoid API rate limits
      }
    }

    detectEmotion()
  }

  return (
    <div className="relative">
      {/* Camera Toggle Button */}
      <motion.button
        onClick={onToggle}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        className={`p-4 rounded-full backdrop-blur-sm border transition-all duration-200 ${
          isEnabled 
            ? 'bg-green-500/20 border-green-500/30 text-green-400' 
            : 'bg-gray-500/20 border-gray-500/30 text-gray-400 hover:bg-gray-500/30'
        }`}
      >
        {isEnabled ? <Eye className="w-6 h-6" /> : <EyeOff className="w-6 h-6" />}
      </motion.button>

      {/* Hidden Video Element */}
      <video
        ref={videoRef}
        className="hidden"
        autoPlay
        muted
        playsInline
      />

      {/* Hidden Canvas for Frame Capture */}
      <canvas
        ref={canvasRef}
        className="hidden"
        width={640}
        height={480}
      />

      {/* Status Indicator */}
      {isEnabled && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="absolute -bottom-12 left-1/2 -translate-x-1/2 text-center"
        >
          <div className="bg-white/10 backdrop-blur-sm rounded-lg px-3 py-1 border border-white/20">
            <p className="text-white/80 text-xs">
              {isInitialized ? '👁️ Watching your mood' : '📷 Starting camera...'}
            </p>
          </div>
        </motion.div>
      )}
    </div>
  )
}