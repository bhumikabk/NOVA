import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Settings, X, Check, Zap } from 'lucide-react'
import { aiModelService } from '../services/aiModels'
import type { AIModel } from '../services/aiModels'

interface ModelSelectorProps {
  currentModel: string
  onModelChange: (modelId: string) => void
  onModelIntroduction: (introduction: string) => void
}

export default function ModelSelector({ 
  currentModel, 
  onModelChange, 
  onModelIntroduction 
}: ModelSelectorProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [models] = useState<AIModel[]>(aiModelService.getModels())

  const handleModelSelect = (modelId: string) => {
    if (modelId !== currentModel) {
      onModelChange(modelId)
      const introduction = aiModelService.getModelIntroduction(modelId)
      onModelIntroduction(introduction)
      setIsOpen(false)
    }
  }

  const currentModelInfo = models.find(model => model.id === currentModel)

  return (
    <>
      {/* Settings Button */}
      <motion.button
        onClick={() => setIsOpen(true)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="fixed top-4 right-4 z-40 p-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white hover:bg-white/20 transition-all duration-200"
      >
        <Settings className="w-6 h-6" />
      </motion.button>

      {/* Current Model Indicator */}
      {currentModelInfo && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed top-4 left-4 z-40 px-4 py-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white"
        >
          <div className="flex items-center gap-2">
            <span className="text-2xl">{currentModelInfo.icon}</span>
            <div>
              <p className="text-sm font-medium">{currentModelInfo.name}</p>
              <p className="text-xs text-white/70">{currentModelInfo.provider}</p>
            </div>
          </div>
        </motion.div>
      )}

      {/* Modal Overlay */}
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
              onClick={() => setIsOpen(false)}
            />

            {/* Modal Content */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-md bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6 z-50"
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-bold text-white">AI Models</h2>
                  <p className="text-sm text-white/70">Choose your AI companion</p>
                </div>
                <motion.button
                  onClick={() => setIsOpen(false)}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </motion.button>
              </div>

              {/* Model List */}
              <div className="space-y-3">
                {models.map((model) => (
                  <motion.button
                    key={model.id}
                    onClick={() => handleModelSelect(model.id)}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    disabled={!model.available}
                    className={`w-full p-4 rounded-xl border transition-all duration-200 text-left ${
                      model.id === currentModel
                        ? 'bg-blue-500/20 border-blue-500/50 text-white'
                        : model.available
                        ? 'bg-white/5 border-white/20 text-white hover:bg-white/10 hover:border-white/30'
                        : 'bg-gray-500/10 border-gray-500/20 text-gray-500 cursor-not-allowed'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{model.icon}</span>
                        <div>
                          <h3 className="font-semibold">{model.name}</h3>
                          <p className="text-sm opacity-70">{model.provider}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {model.available ? (
                          <div className="flex items-center gap-1 text-green-400">
                            <Zap className="w-4 h-4" />
                            <span className="text-xs">Ready</span>
                          </div>
                        ) : (
                          <span className="text-xs text-gray-500">Unavailable</span>
                        )}
                        {model.id === currentModel && (
                          <Check className="w-5 h-5 text-blue-400" />
                        )}
                      </div>
                    </div>
                    <p className="text-xs mt-2 opacity-70">{model.description}</p>
                  </motion.button>
                ))}
              </div>

              {/* Footer */}
              <div className="mt-6 pt-4 border-t border-white/10">
                <p className="text-xs text-white/50 text-center">
                  Each AI model has unique capabilities and personality traits
                </p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}