import React from 'react'
import { motion } from 'framer-motion'
import { Volume2 } from 'lucide-react'
import type { Message } from '../../types'

interface ChatMessageProps {
  message: Message
}

export default function ChatMessage({ message }: ChatMessageProps) {
  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    })
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
    >
      <div className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl ${
        message.role === 'user'
          ? `bg-gradient-to-br ${
              message.emotion?.mood === 'romantic' ? 'from-pink-500 to-red-600' :
              message.emotion?.mood === 'funny' ? 'from-yellow-500 to-orange-600' :
              message.emotion?.mood === 'serious' ? 'from-gray-600 to-blue-700' :
              message.emotion?.mood === 'playful' ? 'from-purple-500 to-pink-600' :
              message.emotion?.mood === 'energetic' ? 'from-green-500 to-teal-600' :
              'from-blue-500 to-purple-600'
            } text-white`
          : `bg-gradient-to-br ${
              message.emotion?.mood === 'romantic' ? 'from-pink-500/20 to-red-600/20 border-pink-500/30' :
              message.emotion?.mood === 'funny' ? 'from-yellow-500/20 to-orange-600/20 border-yellow-500/30' :
              message.emotion?.mood === 'serious' ? 'from-gray-600/20 to-blue-700/20 border-gray-500/30' :
              message.emotion?.mood === 'playful' ? 'from-purple-500/20 to-pink-600/20 border-purple-500/30' :
              message.emotion?.mood === 'energetic' ? 'from-green-500/20 to-teal-600/20 border-green-500/30' :
              'from-white/10 to-white/5 border-white/20'
            } backdrop-blur-sm border text-white`
      }`}>
        <p className="text-sm leading-relaxed">{message.content}</p>
        <div className="flex items-center justify-between mt-2">
          <span className="text-xs opacity-70">
            {formatTime(message.timestamp)}
          </span>
          <div className="flex items-center gap-2 text-xs opacity-70">
            {message.type === 'voice' && (
              <div className="flex items-center gap-1">
                <Volume2 className="w-3 h-3" />
                Voice
              </div>
            )}
            {message.emotion && (
              <div className="flex items-center gap-1">
                <span>{
                  message.emotion.emotion === 'happy' ? '😊' :
                  message.emotion.emotion === 'sad' ? '😔' :
                  message.emotion.emotion === 'angry' ? '😤' :
                  message.emotion.emotion === 'surprised' ? '😲' :
                  message.emotion.emotion === 'excited' ? '🤩' :
                  message.emotion.emotion === 'confused' ? '🤨' :
                  '😊'
                }</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  )
}